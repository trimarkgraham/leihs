FactoryGirl.define do

  factory :purpose do
    description { Faker::Lorem.sentence }
  end

end
