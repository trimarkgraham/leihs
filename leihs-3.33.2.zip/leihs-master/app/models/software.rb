class Software < Model

end
