module Availability
  module InventoryPool

    attr_accessor :loaded_group_ids

  end
end
