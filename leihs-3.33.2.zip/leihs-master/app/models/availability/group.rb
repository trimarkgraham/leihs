module Availability
    module Group

      GENERAL_GROUP_ID = nil

    end
end
