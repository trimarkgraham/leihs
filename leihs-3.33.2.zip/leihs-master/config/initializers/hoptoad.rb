# TODO switch on/off through settings 


# Disable for now, it messes things up on hosts that don't
# have Internet connectivity.
#HoptoadNotifier.configure do |config|
#  config.api_key = '2f95bc0b2e9bfbd1d796cafad830c2cc'
#  config.environment_filters << 'rack-bug.*'
#end
