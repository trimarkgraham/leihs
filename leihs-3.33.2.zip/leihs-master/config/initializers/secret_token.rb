# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Leihs::Application.config.secret_token = 'c06439c677c5bbcecf39085670340f8b99f02af5ec5a45af7c700ed18c6f5985989e832af6749599e5d5885e093d5c382c351d59791aff690532c2f41896e37f'
Leihs::Application.config.secret_key_base = 'bdb8c561528d1343a658373562c9fe22924ef451e526de20cb61a2e4bf9dc7eb3affcd9dd4d8bd34218d4d8883e93d7fc6c85c873bfb16305aaf1f8a4fb843d6'
