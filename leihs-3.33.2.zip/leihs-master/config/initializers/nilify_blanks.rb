# https://github.com/rubiety/nilify_blanks#global-usage

ActiveRecord::Base.nilify_blanks
