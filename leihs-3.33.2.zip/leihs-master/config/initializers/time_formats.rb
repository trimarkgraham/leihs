
# Time::DATE_FORMATS[:month_and_year] = "%B %Y"
Date::DATE_FORMATS[:month_and_year] = "%B %Y"
Date::DATE_FORMATS[:with_weekday_name] = "%d. %b %Y, %A"
