# encoding: utf-8
# This file will stay empty, we are using the capistrano
# multistage extension to manage multiple deployment
# configs instead.


default_run_options[:shell] = "/bin/bash --login"
