Rails.application.routes.draw do

  mount LeihsAdmin::Engine => "/leihs_admin"
end
