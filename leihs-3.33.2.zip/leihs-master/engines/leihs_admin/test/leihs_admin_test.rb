require 'test_helper'

class LeihsAdminTest < ActiveSupport::TestCase
  test "truth" do
    assert_kind_of Module, LeihsAdmin
  end
end
