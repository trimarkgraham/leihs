module LeihsAdmin
  module ApplicationHelper
  end
end
