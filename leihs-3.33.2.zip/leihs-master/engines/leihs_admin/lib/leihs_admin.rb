require 'leihs_admin/engine'

module LeihsAdmin
end
